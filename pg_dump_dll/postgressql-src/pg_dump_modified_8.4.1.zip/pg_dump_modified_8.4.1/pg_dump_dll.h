#include "mi_global_pwd.h"

//pdmvm = pasho_dolzhen_misho_vedro_marozhina

__declspec(dllexport) int pdmvm_dump (char * app_exe,
                                      char * database,
				char * pwd,
				char * err_str,
				wchar_t * out_file,
				wchar_t * err_file,
				char * params);//this is NULL-ended array of pointers

int pdmvm_dump (char * app_exe,
                char * database,
								char * pwd,
								char * err_str,
								wchar_t * out_file, //pago rulez!
								wchar_t * err_file,
								char * params)//this NULL ended array of pointers
{
  char ** mas;
  int cnt = 0;
  int c = 0;
  char ** arr;
  char ** arr2;
  int r;

  	mi_errno = 0;

  //reset error str
  mi_clear_last_error();

//  mi_die_not_so_horribly("test", "test2 %s", "gigi"); //just for test

  //count params number
  arr = (char **) params;
  while (*arr)
  {
	  c++;
	  arr++;
  }

	c += 2;// exe_name and database name

  //prepare argv array
	mas = (char ** ) malloc(c * sizeof(char *));

	arr = (char **) params;
	arr2 = mas;

	* arr2 = strdup(app_exe);
	arr2++;
	cnt++;

  while (*arr)
  {
    * arr2 = strdup(*arr);
	  arr2++;
	  cnt++;

		arr++;
  }

	* arr2 = strdup(database);
	arr2++;
	cnt++;

  strcpy(mi_global_pwd, pwd);

	//default err str
	mi_set_err("OK!");

	//reassigning stdout and stderr
	stream1 = NULL;
	stream2 = NULL;

	if (out_file)
	{
		stream1 = _wfreopen(out_file, L"w", stdout);
		if(!stream1)
		{
			strcpy(err_str, "Error reassigning stdout");
			r = 3;
			goto _end;
		}
	}

	if (err_file)
	{
		stream2 = _wfreopen(err_file, L"w", stderr);
		if(!stream2)
		{
			strcpy(err_str, "Error reassigning stderr");
			r = 3;
			goto _end;
		}
	}

	r =  main(cnt, mas);

	if (r != 0)
	{
		strcpy(err_str, mi_global_err);
		if (mi_MEGAERROR != 0)
			r = mi_MEGAERROR;
	}

_end:
	//clear grabbed memory
	arr2 = mas;
	while(cnt--)
	{
		free(*arr2);
		arr2 ++;
	}
	free(mas);

	//closing file
	if(stream1)
		fclose(stream1);
	if(stream2)
		fclose(stream2);

	freopen("CON", "w", stdout);
	freopen("CON", "w", stderr);		

	//return result
	return r;
};
