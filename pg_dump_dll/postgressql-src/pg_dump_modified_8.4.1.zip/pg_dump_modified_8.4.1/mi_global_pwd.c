#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include "mi_global_pwd.h"

char mi_global_pwd[256];
char mi_global_err[256];
int mi_errno;

char mi_last_die_error[256];

wchar_t	*inputFileSpec; //pago for restore 

//for sdtout and stderr reassigning
FILE * stream1;
FILE * stream2;

//prototypes
char * mi_get_password(void);
void mi_set_err(char * s);
void mi_die_not_so_horribly(const char *modulename, const char *fmt, ...);
void mi_clear_last_error(void);

//implementation
void mi_set_err(char * s)
{
	strcpy(mi_global_err, s);
};

char * mi_get_password(void)
{
	char * s;

	s = (char *) malloc(strlen(mi_global_pwd) + 1);
	strcpy(s, mi_global_pwd);

	return s;
};

ErrorCallBackProc_ptr ErrorCallBackProc = NULL;
LogCallBackProc_ptr LogCallBackProc = NULL;

void mi_die_not_so_horribly(const char *modulename, const char *fmt, ...)
{
//  FILE * f = fopen("aaa.aaa", "a");
//  fprintf(f, "*** mi_die_not_so_horribly ***\n");
//  fclose(f);

  va_list args;
  char s[256];

  va_start(args, fmt);
  vsnprintf(s, 256, fmt, args);
  va_end(args);
	sprintf(mi_last_die_error,"%s: %s", modulename, s);


//  f = fopen("aaa.aaa", "a");
//  fprintf(f, "*** mi_die_not_so_horribly CHEKPOINT 2 ***\n");
//  fclose(f);

	//closing reassignments files
	if(stream1)
		fclose(stream1);
	if(stream2)
		fclose(stream2);

  if(!ErrorCallBackProc) //using old scheme
  {
//  FILE * f = fopen("aaa.aaa", "a");
//  fprintf(f, "*** FAKE_AV_ADDRESS_DIE_HORRIBLY: %s - %s ***\n", modulename, s);
//  fclose(f);

    //main trick of pdmbvm //mi 2007-01-15 this is not real trick... this is just a podsos. the real trick is in else section.
    *((int *) FAKE_AV_ADDRESS_DIE_HORRIBLY) = 0;
    //*((int *) 0x234) = 0;
  }
  else
  {
    //printf("*******8 !!! ********");
    //write_msg(NULL, "*** PDMBVM aborted because of error ***\n");
//  FILE * f = fopen("aaa.aaa", "a");
//  fprintf(f, "*** ErrorCallBackProc: %s - %s ***\n", modulename, s);
//  fclose(f);

    ErrorCallBackProc(modulename, s);
  }
  
  exit(-1);//if callback was modified by someone stupid - we must die horribly
};

void mi_clear_last_error(void)
{
  mi_last_die_error[0] = (char)0;
};

void pdmbvm_SetErrorCallBackProc(void * ptr)
{
  ErrorCallBackProc = (ErrorCallBackProc_ptr) ptr;
};

void pdmbvm_SetLogCallBackProc(void * ptr)
{
  LogCallBackProc = (LogCallBackProc_ptr) ptr;
};
