#include "pg_config.h"

#include "mi_global_pwd.h"

//pdmbvm = pasho_dolzhen_misho_bolshoe_vedro_marozhina

__declspec(dllexport) void pdmbvm_GetLastError(char * aStr);
__declspec(dllexport) int pdmbvm_GetVersionAsInt(void);

void pdmbvm_GetLastError(char * aStr)
{
   strcpy(aStr, mi_last_die_error);
};

int pdmbvm_GetVersionAsInt(void)
{
  return PG_VERSION_NUM;
};


