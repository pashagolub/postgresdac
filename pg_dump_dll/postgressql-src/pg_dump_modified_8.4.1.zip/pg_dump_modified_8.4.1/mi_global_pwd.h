
#ifndef MI_GLOBAL_PWD_H
#define MI_GLOBAL_PWD_H

#define FAKE_AV_ADDRESS_DIE_HORRIBLY 0x00000159
#define FAKE_AV_ADDRESS_EXIT_NICELY FAKE_AV_ADDRESS_DIE_HORRIBLY + 1

__declspec(dllexport) void pdmbvm_SetErrorCallBackProc(void * ptr);
__declspec(dllexport) void pdmbvm_SetLogCallBackProc(void * ptr);

extern char mi_global_pwd[256];
extern char mi_global_err[256];
extern char mi_last_die_error[256];

extern	wchar_t	   *inputFileSpec; //pago for restore 

extern int mi_errno;

extern char * mi_get_password(void);
extern void mi_set_err(char * s);

extern FILE * stream1;
extern FILE * stream2;

typedef void (__cdecl *ErrorCallBackProc_ptr)(const char *, const char *);
typedef void (__cdecl *LogCallBackProc_ptr)(char *);
extern LogCallBackProc_ptr LogCallBackProc;

void mi_die_not_so_horribly(const char *modulename, const char *fmt, ...);
void mi_clear_last_error(void);

#endif   /* MI_GLOBAL_PWD_H */
