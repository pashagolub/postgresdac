#include "mi_global_pwd.h"

//pdmvm = pasho_dolzhen_misho_vedro_marozhina

__declspec(dllexport) int pdmvm_restore (char * app_exe,
                                         wchar_t * file_path,
					char * pwd,
					wchar_t * out_file,
					wchar_t * err_file,
					char * params);//this NULL ended array of pointers

int pdmvm_restore (char * app_exe,
                   wchar_t * file_path,
		   char * pwd,
		   wchar_t * out_file,
		   wchar_t * err_file,
		   char * params)//this NULL ended array of pointers
{
  char ** mas;
  int cnt = 0;
  int c = 0;
  char ** arr;
  char ** arr2;
	int r;

	mi_errno = 0;

  //reset error str
  mi_clear_last_error();

  //count params number
  arr = (char **) params;
  while (*arr)
  {
	  c++;
	  arr++;
  }

	c += 2;// exe_name and database name

  //prepare argv array
	mas = (char ** ) malloc(c * sizeof(char *));

	arr = (char **) params;
	arr2 = mas;

	* arr2 = strdup(app_exe);
	arr2++;
	cnt++;
	
  	

  while (*arr)
  {
    * arr2 = strdup(*arr);
	  arr2++;
	  cnt++;

		arr++;
  }

//	* arr2 = _wcsdup(file_path);
//	arr2++;
//	cnt++;

  inputFileSpec = wcsdup(file_path); //pago

  strcpy(mi_global_pwd, pwd);

	//reassigning stdout and stderr
	if (out_file)
	{
		stream1 = _wfreopen(out_file, L"w", stdout);
		if(!stream1)
		{
			r = 3;
			//mi_last_die_error = "Cannot reassign standard output";
			goto _end;
		}
	}

	if (err_file)
	{
		stream2 = _wfreopen(err_file, L"w", stderr);
		if(!stream2)
		{
			r = 4;
			//mi_last_die_error = "Cannot reassign error output";
			goto _end;
		}
	}

	//calling main()
	r =  main(cnt, mas);

	if (r != 0)
	{
		if (mi_MEGAERROR != 0)
			r = mi_MEGAERROR;
	}

_end:
	//clear grabbed memory
	arr2 = mas;
	while(cnt--)
	{
		free(*arr2);
		arr2 ++;
	}
	free(mas);

	//closing file
	if(stream1)
		fclose(stream1);
	if(stream2)
		fclose(stream2);
		
	freopen("CON", "w", stdout);
	freopen("CON", "w", stderr);		

	//return result
	return r;
};
